package com.example.travel_app;

public class placeList
{
    private String placeTitle;
    private String placeDescription;
    private Integer placeImage;

    public placeList(String place_title,String placeDescription, Integer placeImage)
    {
        this.placeTitle = place_title;
        this.placeDescription = placeDescription;
        this.placeImage = placeImage;
    }

    public String getPlaceTitle()
    {
        return  placeTitle;
    }
    public String getPlaceDescription()
    {
        return  placeDescription;
    }

    public Integer getPlaceImage()
    {
        return placeImage;
    }

    public void setPlaceTitle(String placeTitle)
    {
        this.placeTitle = placeTitle;
    }
    public void setPlaceDescription(String placeDescription)
    {
        this.placeDescription = placeDescription;
    }

    public void setPlaceImage(Integer placeImage)
    {
        this.placeImage = placeImage;
    }

}
