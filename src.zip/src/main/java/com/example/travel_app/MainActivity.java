package com.example.travel_app;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView, recyclerView1;
    RecyclerViewAdapter recyclerViewAdapter;
    RecyclerViewAdapter1 recyclerViewAdapter1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView1 = findViewById(R.id.recyclerView1);





        placeList[] placeListData_final = new placeList[]{
                new placeList("Paris", "Paris is the capital and most populous city of France.", R.drawable.paris),
                new placeList("Dubai", "Dubai is one of the world's most popular tourist destinations with the second most five-star hotels in the world.", R.drawable.dubai),
                new placeList("Melbourne", "Melbourne is the capital and most-populous city of the Australian state of Victoria.", R.drawable.melbourne),
                new placeList("Sydney", "Sydney  is the capital city of the state of New South Wales.", R.drawable.sydney),
                new placeList("Chandigarh", "Chandigarh is bordered by the state of Punjab.", R.drawable.chandigarh),
                new placeList("Tasmania", "Tasmania abbreviated as Tas, nicknamed Tassie, Bruny Island Tasmanian.", R.drawable.tasmania),
                new placeList("Gold Coast", "The Gold Coast is a coastal city in the Australian state of Queensland.", R.drawable.gold_coast),
                new placeList("Spain", "Spain is a country in Southwestern Europe.", R.drawable.spain),

        };

        placeList1[] placeListData_final1  = new placeList1[]
                {
                        new placeList1("Sydney",R.drawable.sydney),
                        new placeList1("Chandigarh", R.drawable.chandigarh),
                        new placeList1("Tasmania", R.drawable.tasmania),
                        new placeList1("Gold Coast", R.drawable.gold_coast),
                        new placeList1("Spain", R.drawable.spain),
                        new placeList1("Paris",R.drawable.paris),
                        new placeList1("Dubai", R.drawable.dubai),
                        new placeList1("Melbourne",R.drawable.melbourne),

                };




        recyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false));
        recyclerView1.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));
        recyclerViewAdapter = new RecyclerViewAdapter(placeListData_final, MainActivity.this);
        recyclerViewAdapter1 = new RecyclerViewAdapter1(placeListData_final1, MainActivity.this);
        recyclerView.setAdapter(recyclerViewAdapter);
        recyclerView1.setAdapter(recyclerViewAdapter1);


    }
}