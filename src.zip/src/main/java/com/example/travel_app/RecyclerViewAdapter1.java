package com.example.travel_app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

public class RecyclerViewAdapter1 extends RecyclerView.Adapter<RecyclerViewAdapter1.ViewHolder>
{
    placeList1[] placeListData1;
    Context context;


    public RecyclerViewAdapter1(placeList1[] placeListData1, MainActivity activity) {
        this.placeListData1 = placeListData1;
        this.context = activity;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.place_layout1,parent,false);
        ViewHolder viewHolder1 = new ViewHolder(view);
        return viewHolder1;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position)
    {
        final placeList1 placeListData_final1  = placeListData1[position];

        holder.topRowTitleTextView.setText(placeListData_final1.getPlaceTitle1());
        holder.topRowImageView.setImageResource(placeListData_final1.getPlaceImage1());

        holder.itemView.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if(placeListData_final1.getPlaceTitle1() == "Paris")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    ParisFragment parisFragment = new ParisFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, parisFragment).addToBackStack(null).commit();
                }
                else if(placeListData_final1.getPlaceTitle1() == "Dubai")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    DubaiFragment dubaiFragment = new DubaiFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, dubaiFragment).addToBackStack(null).commit();

                }

                else if(placeListData_final1.getPlaceTitle1() == "Melbourne")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    MelbourneFragment melbourneFragment = new MelbourneFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec,melbourneFragment).addToBackStack(null).commit();

                }

                else if(placeListData_final1.getPlaceTitle1() == "Sydney")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    SydneyFragment sydneyFragment = new SydneyFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, sydneyFragment).addToBackStack(null).commit();

                }

                else if(placeListData_final1.getPlaceTitle1() == "Chandigarh")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    ChandigarhFragment chandigarhFragment = new ChandigarhFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, chandigarhFragment).addToBackStack(null).commit();

                }

                else if(placeListData_final1.getPlaceTitle1() == "Tasmania")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    TasmaniaFragment tasmaniaFragment = new TasmaniaFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, tasmaniaFragment).addToBackStack(null).commit();

                }

                else if(placeListData_final1.getPlaceTitle1() == "Gold Coast")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    GoldCoastFragment goldCoastFragment = new GoldCoastFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, goldCoastFragment).addToBackStack(null).commit();

                }

                else if(placeListData_final1.getPlaceTitle1() == "Spain")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    SpainFragment spainFragment = new SpainFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.rec, spainFragment).addToBackStack(null).commit();

                }

                else
                {
                    Toast.makeText(context, placeListData_final1.getPlaceTitle1(), Toast.LENGTH_SHORT).show();
                }

            }
        });
    }


    @Override
    public int getItemCount() {
        return placeListData1.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView topRowTitleTextView;
        ImageView topRowImageView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            topRowTitleTextView = itemView.findViewById(R.id.topRowTitleTextView);
            topRowImageView = itemView.findViewById(R.id.topRowImageView);
        }
    }
}
