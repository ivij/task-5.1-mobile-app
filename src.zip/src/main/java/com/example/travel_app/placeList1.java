package com.example.travel_app;
public class placeList1
{
    private String placeTitle1;
    private Integer placeImage1;

    public placeList1(String place_title1, Integer placeImage1)
            {
            this.placeTitle1 = place_title1;
            this.placeImage1 = placeImage1;
            }

    public String getPlaceTitle1()
            {
            return  placeTitle1;
            }


    public Integer getPlaceImage1()
            {
            return placeImage1;
            }

    public void setPlaceTitle1(String placeTitle1)
            {
            this.placeTitle1 = placeTitle1;
            }


    public void setPlaceImage1(Integer placeImage1)
            {
            this.placeImage1 = placeImage1;
            }

        }
